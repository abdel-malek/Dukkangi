<!doctype html>
<html lang="en">
  <head>
    @include('partials._head')
  </head>

  <body>
    <div class = "container">

      @yield('content')


    </div>
  </body>
@yield ('scripts')

</html>